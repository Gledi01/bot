rm -rf kayyoffc.js
cp /sdcard/kayyoffc.js ./
