#!/bin/bash

# Nama file hasil kompres
OUTPUT="project.tar.gz"

# Kompres semua isi direktori kecuali .node_modules
tar --exclude="./node_modules" -czvf "$OUTPUT" ./*
