const fs = require('fs')

let store = {
  chats: {},
  groups: {}
}

// Cek apakah file store.json udah ada
if (fs.existsSync('./store.json')) {
  try {
    store = JSON.parse(fs.readFileSync('./store.json', 'utf-8'))
    console.log('[STORE] Loaded store.json')
  } catch (e) {
    console.error('[STORE] Gagal load:', e)
  }
}

// Simpan otomatis tiap 10 detik
setInterval(() => {
  fs.writeFileSync('./store.json', JSON.stringify(store, null, 2))
}, 10000)

module.exports = store
